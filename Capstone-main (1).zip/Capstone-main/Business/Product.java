package Business;

import java.sql.*;

public class Product {
    private int productId;
    private String productName;
    private double price;
    // Add other product-related fields as needed

    public Product() {
        this.productId = 0;
        this.productName = "";
        this.price = 0.0;
    }
    

    public Product(int productId, String productName, double price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
	}
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}


	// Getter methods for fields

    public void selectProduct(int productId) throws ClassNotFoundException {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://" + "/Users/blainebechtel/Desktop/Capstone/Capstone/src/GreetingCardsDB1.accdb")) {
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Products WHERE ProductID = ?");
                pstmt.setInt(1, productId);

                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    // Populate fields with data from the result set
                    this.setProductId(rs.getInt("ProductID"));
                    this.setProductName(rs.getString("ProductName"));
                    this.setPrice(rs.getDouble("Price"));
                    // Add more fields as needed
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

}

