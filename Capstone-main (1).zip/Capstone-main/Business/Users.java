package Business; 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class Users {
    private int UserID;
    private String FirstName;
    private String LastName;
    private String Address;
    private String Email;
    private String Password;
    private String ClientType;
    
    public Users(){
        this.UserID = 0;
        this.FirstName = "";
        this.LastName = "";
        this.Address = "";
        this.Email = "";
        this.Password = "";
        this.ClientType = "";
    }
        
        public Users(int UserID, String FirstName, String LastName, String Address, String Email ,String Password, String ClientType ){
            this.UserID = UserID;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Address = Address;
            this.Email = Email;
            this.Password = Password;
            this.ClientType = ClientType;
        }
        public void selectDB(String Email) throws ClassNotFoundException{
            
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb")) {
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Users WHERE Email = ?");
               pstmt.setString(1, Email);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()){
                	
                   this.UserID = rs.getInt("UserID");
                   this.FirstName = rs.getString("FirstName");
                   this.LastName = rs.getString("LastName");
                   this.Address = rs.getString("Address");
                   this.Email = rs.getString("Email");
                   this.Password = rs.getString("Password");
                   this.ClientType = rs.getString("ClientType");
                   
                }

            }
            catch (SQLException e) {
            System.out.println(e);
        }
            
        }
         public void insertDB(int UserID, String FirstName, String LastName, String Address, String Email ,String Password, String ClientType ) {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb")) {
                PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Users (UserID,FirstName,LastName,Address,Email,Password,ClientType) VALUES (?, ?, ?, ?,?,?,?)");

                pstmt.setInt(1, UserID);
                pstmt.setString(2, FirstName);
                pstmt.setString(3, LastName);
                pstmt.setString(4,Address);
                pstmt.setString(5, Email);
                pstmt.setString(6, ClientType);

                pstmt.executeUpdate();
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
    }

    public void deleteDB() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb")) {
                PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Users WHERE UserID = ?");
                pstmt.setInt(1, this.UserID);
                pstmt.executeUpdate();
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
    }
    public void updateProfile(String Email, String Address, String FirstName, String LastName, String ClientType) {
           try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            StringBuilder queryBuilder = new StringBuilder("UPDATE Users SET ");
            queryBuilder.append(" WHERE email = ?");

            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb")) {
                PreparedStatement pstmt = conn.prepareStatement(queryBuilder.toString());
                boolean hasUpdate = false;

                if (Address != null) {
                    queryBuilder.append("Address = ?, ");
                    hasUpdate = true;
                }

                if (FirstName != null) {
                    queryBuilder.append("FirstName = ?, ");
                    hasUpdate = true;
                }

                if (LastName != null) {
                    queryBuilder.append("LastName = ?, ");
                    hasUpdate = true;
                }

                if (ClientType != null) {
                    queryBuilder.append("ClientType = ?, ");
                    hasUpdate = true;
                }
                if (hasUpdate) {
                    // Remove the trailing comma and space
                    queryBuilder.setLength(queryBuilder.length() - 2);

                    queryBuilder.append(" WHERE Email = ?");

                    PreparedStatement pstmt1 = conn.prepareStatement(queryBuilder.toString());

                    int parameterIndex = 1;

                    if (Address != null) {
                        pstmt1.setString(parameterIndex++, Address);
                    }

                    if (FirstName != null) {
                        pstmt1.setString(parameterIndex++, FirstName);
                    }
                    if (LastName != null) {
                        pstmt1.setString(parameterIndex++, Address);
                    }

                    if (ClientType != null) {
                        pstmt1.setString(parameterIndex++, FirstName);
                    }
                    pstmt1.setString(parameterIndex, Email);

                    int rowsAffected = pstmt1.executeUpdate();

                    if (rowsAffected > 0) {
                        System.out.println("User profile updated successfully.");
                    } else {
                        System.out.println("No user found with the specified email.");
                    }
                } else {
                    System.out.println("No fields provided for update.");
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
    }


    public void display() {
        System.out.println("UserID = " + UserID);
        System.out.println("First Name: " + FirstName);
        System.out.println("Last Name: " + LastName);
        System.out.println("Address: " + Address);
         System.out.println("Email: " + Email);
          System.out.println("Password: " + Password);
          System.out.println("Client Type: " + ClientType);
    }
    

    public static void main(String[] args) throws ClassNotFoundException {
        String Email = "lsmith@gmail.com";
        Users u1 = new Users();
        u1.updateProfile(Email, null, null, null, null);
        u1.selectDB(Email);
        u1.display(); 

    }

    public int getUserID() {
//        log("UserID: " + UserID);
        return UserID;
        
    }
    
    public String getFirstName(){
//        log("First Name: " + FirstName);
        return FirstName;
    }

    public String getLastName(){
//        log("Last Name: " + LastName);
        return LastName;
    }
    
    public String getAddress() {
//                log("Address: " + Address);
                return Address;
    }
                
     public String getEmail() {
//                log("Email: " + Email);
                return Email;
     }
                
     public String getPassword() {
//                log("Password: " + Password);
                return Password;
     }
      public String getClientType() {
//                log("Client Type: " + ClientType);
                return ClientType;

        
    }


}
    

