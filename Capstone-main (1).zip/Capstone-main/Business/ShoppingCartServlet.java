package Business;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/addToCart")
public class ShoppingCartServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//	private static final String DB_URL = "jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb";
//    private static final String DB_USER = "your_db_user";
//    private static final String DB_PASSWORD = "your_db_password";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve user ID and product ID from the request (validate inputs accordingly)
        int userId = Integer.parseInt(request.getParameter("userId"));
        int productId = Integer.parseInt(request.getParameter("productId"));

        // Add the product to the cart
        boolean addedToCart = addToCart(userId, productId);

        // Send a JSON response
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.print("{\"success\": " + addedToCart + "}");
        out.flush();
    }
    
    public static boolean addToCart(int userId, int productId) {
        try {
            // Load the JDBC driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb")) {
                // Check if the product is already in the cart
                if (!isProductInCart(userId, productId)) {
                    // Add the product to the cart
                    String sql = "INSERT INTO Cart (UserId, ProductId) VALUES (?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, userId);
                        pstmt.setInt(2, productId);
                        int rowsAffected = pstmt.executeUpdate();

                        // Return true if at least one row was affected
                        return rowsAffected > 0;
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
		return false;
    }

    private static boolean isProductInCart(int userId, int productId) throws ClassNotFoundException {
        try {

            // Load the JDBC driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            // Establish the database connection
            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb")) {
                // Check if the product is in the cart
                String sql = "SELECT * FROM Cart WHERE UserId = ? AND ProductId = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, userId);
                    pstmt.setInt(2, productId);
                    ResultSet resultSet = pstmt.executeQuery();
                    return resultSet.next();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<String> getCartProducts(int userId) {
        List<String> cartProducts = new ArrayList<>();
        try {

            // Load the JDBC driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            // Establish the database connection
            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb")) {
                // Retrieve products from the cart
                String sql = "SELECT p.ProductName FROM Cart c INNER JOIN Products p ON c.ProductId = p.ProductId WHERE c.UserId = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, userId);
                    ResultSet resultSet = pstmt.executeQuery();
                    while (resultSet.next()) {
                        cartProducts.add(resultSet.getString("ProductName"));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return cartProducts;
    }

    @SuppressWarnings("unused")
	private boolean checkout(int userId) {
        try {
            // Load the JDBC driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/jairp/OneDrive/Desktop/delanie Java labs/GreetingCards/GreetingCardsDB (2).accdb")) {
                // Prepare the SQL statement to check out items from the cart
                String checkoutSql = "SELECT * FROM Cart WHERE UserId = ?";
                try (PreparedStatement checkoutStmt = conn.prepareStatement(checkoutSql)) {
                    checkoutStmt.setInt(1, userId);

                    // Execute the query
                    ResultSet resultSet = checkoutStmt.executeQuery();

                    // Process the results (you may want to update your order table or perform other actions)
                    while (resultSet.next()) {
                        int productId = resultSet.getInt("ProductId");
                        int quantity = resultSet.getInt("Quantity");

                        // Perform checkout logic here (e.g., update order table, deduct inventory, etc.)
                        System.out.println("Checkout ProductId: " + productId + ", Quantity: " + quantity);
                    }

                    // Return true if the checkout was successful
                    return true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        // Return false if the checkout was not successful
        return false;
    }
   

}


